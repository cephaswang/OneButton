//
//  Menu.swift
//  split
//
//  Created by admin on 2022/4/5.
//

import UIKit

class Menu: UIViewController {

    let myView : UIView = {
        let t = UIView()
        t.translatesAutoresizingMaskIntoConstraints = false
        return t
    }()
    
    let imageView : UIImageView = {
        let t = UIImageView()
        t.translatesAutoresizingMaskIntoConstraints = false
        return t
    }()
    
    var dateNext: UIButton?
    var dateReset: UIButton?
    var datePrev: UIButton?
    var tableView: UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        view.contentMode = .scaleAspectFill
        
        self.title = "|"
        
        initButton ()

        print ( view.frame )
        // Do any additional setup after loading the view.
    }

    func initButton () {
       self.view.addSubview(myView)
        view.backgroundColor = .red
        myView.frame = view.bounds

        myView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 102).isActive = true
        myView.topAnchor.constraint(equalTo: view.topAnchor, constant: 80).isActive = true
        myView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -2).isActive = true
        myView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -2).isActive = true
        myView.backgroundColor = .green
        myView.contentMode = .scaleToFill
        
        print ("myView.frame:\(myView.frame)")

        var SizeX:CGFloat = (self.navigationController?.navigationBar.frame.width)!
        SizeX = SizeX - 104
        
        print ( "SizeX:\(SizeX)")
        
        datePrev = UIButton(frame: CGRect(x:0, y:0, width: 60, height: 60))
        datePrev?.setImage(UIImage(named: "date_dec.png"), for: UIControl.State.normal)
        myView.addSubview(datePrev!)
        datePrev?.center = CGPoint(x:40 , y:40)
        // ----------
        dateReset = UIButton(frame: CGRect(x:0, y:0, width: 60, height: 60))
        dateReset?.setImage(UIImage(named: "date_rst.png"), for: UIControl.State.normal)
        myView.addSubview(dateReset!)
        dateReset?.center = CGPoint(x:SizeX/2 , y:40)

        // ---------- width = 310
        dateNext = UIButton(frame: CGRect(x:0, y:0, width: 60, height: 60))
        dateNext?.setImage(UIImage(named: "date_add.png"), for: UIControl.State.normal)
        myView.addSubview(dateNext!)
        dateNext?.center = CGPoint(x:SizeX-40 , y:40)

        
        print ( imageView.frame.width )

   }

}
