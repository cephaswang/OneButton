//
//  ViewController.swift
//  split
//
//  Created by admin on 2022/4/5.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

